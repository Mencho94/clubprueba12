package arg.org.centro8.curso.java.club.test;

import arg.org.centro8.curso.java.club.entities.Socio;
import arg.org.centro8.curso.java.club.entities.Entrenador;
import arg.org.centro8.curso.java.club.entities.Actividad;
import arg.org.centro8.curso.java.club.enums.Dia;
import arg.org.centro8.curso.java.club.enums.Turno;
import arg.org.centro8.curso.java.club.repositories.EntrenadorRepository;
import arg.org.centro8.curso.java.club.repositories.SocioRepository;
import arg.org.centro8.curso.java.club.repositories.ActividadRepository;

public class TestRepository {
   public static void main(String[] args) {
        ActividadRepository ar=new ActividadRepository();
        Actividad actividad=new Actividad("Yoga", "Ana", Dia.LUNES, Turno.MAÑANA);
        ar.save(actividad);
        System.out.println(actividad);

        ar.getAll().forEach(System.out::println);
        System.out.println(" ");
        System.out.println("******************************");
        System.out.println(ar.getById(1));
        System.out.println("******************************");
        //ar.getLikeNombre("Yoga").forEach(System.out::println);

        SocioRepository sr=new SocioRepository();
        Socio socio=new Socio("Luis", "Gonzalez", 25, 1);
        sr.save(socio);
        System.out.println(socio);

        System.out.println("******************************");
        sr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(sr.getById(1));
        System.out.println("******************************");
        sr.getLikeApellido("Ga").forEach(System.out::println);

        EntrenadorRepository er=new EntrenadorRepository();
        Entrenador entrenador=new Entrenador("Ana", "Garcia", 30, 1);
        er.save(entrenador);
        System.out.println(entrenador);

        System.out.println("******************************");
        er.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(er.getById(1));
        System.out.println("******************************");
        er.getLikeApellido("Ga").forEach(System.out::println);
        
        
   } 
}






